package uk.co.dextersspot.cafegame;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class CafeGameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private Thread loop;
    private volatile boolean running;
    private long lastNs;
    private float W=1280,H=720, scale=1f;
    private final ArrayList<Customer> customers = new ArrayList<>();
    private final ArrayList<Staff> staff = new ArrayList<>();
    private final ArrayList<Order> orders = new ArrayList<>();
    private final String[] menu = {"Coffee","Breakfast Roll","Full Scottish","Street Sub","Nero Smash","Loaded Fries","Rice Bowl","Waffle"};
    private final float[] price = {3.2f,4.5f,9.95f,7.5f,10.5f,6.5f,9.5f,7.25f};
    private float cash=60f, reputation=82f, dayTakings=0f, shiftTime=8*60f, spawnClock=0f, rushClock=0f;
    private int served=0, day=1, level=1, xp=0, counterLevel=1, kitchenLevel=1, tables=3;
    private boolean open=true, rush=false, paused=false;
    private final SharedPreferences prefs;
    private final RectF startButton = new RectF(), counterButton=new RectF(), kitchenButton=new RectF(), hireButton=new RectF();

    public CafeGameView(Context c) {
        super(c); getHolder().addCallback(this); setFocusable(true);
        prefs=c.getSharedPreferences("dexters_native_game_v2",Context.MODE_PRIVATE);
        load();
        text.setTypeface(Typeface.create("sans",Typeface.BOLD));
        staff.add(new Staff("Cashier",530,235,0)); staff.add(new Staff("Chef",780,250,1));
    }

    @Override public void surfaceCreated(SurfaceHolder h){ running=true; lastNs=System.nanoTime(); loop=new Thread(this); loop.start(); }
    @Override public void surfaceDestroyed(SurfaceHolder h){ running=false; save(); try{if(loop!=null)loop.join(800);}catch(Exception ignored){} }
    @Override public void surfaceChanged(SurfaceHolder h,int f,int w,int ht){ W=w;H=ht;scale=Math.min(W/1280f,H/720f); }
    public void resumeGame(){ paused=false; }
    public void pauseGame(){ paused=true; save(); }

    @Override public void run(){ while(running){ long now=System.nanoTime(); float dt=Math.min(.035f,(now-lastNs)/1_000_000_000f); lastNs=now; if(!paused) update(dt); drawFrame(); try{Thread.sleep(12);}catch(Exception ignored){} } }

    private void update(float dt){
        if(open){
            shiftTime += dt*2.2f;
            spawnClock -= dt;
            if(spawnClock<=0 && customers.size()<10){ spawnCustomer(); spawnClock = rush?1.4f:3.3f-(level*.05f); }
        }
        if(rush){ rushClock-=dt; if(rushClock<=0){rush=false; reputation=Math.min(100,reputation+1);} }
        if(!rush && served>0 && served%12==0 && rng.nextFloat()<dt*.12f){rush=true;rushClock=28;}
        for(Staff s:staff) s.update(dt);
        for(int i=customers.size()-1;i>=0;i--){ Customer c=customers.get(i); c.update(dt); if(c.remove) customers.remove(i); }
        for(int i=orders.size()-1;i>=0;i--){ Order o=orders.get(i); o.update(dt); if(o.done){ completeOrder(o); orders.remove(i);} }
        if(shiftTime>=18*60 && open) open=false;
    }

    private void spawnCustomer(){
        int q=queueCount(); float y=600-q*48; int idx=rng.nextInt(menu.length);
        Customer c=new Customer(menu[idx],price[idx],80,670, q, idx); customers.add(c);
    }
    private int queueCount(){int n=0;for(Customer c:customers)if(c.state<=1)n++;return n;}

    private void completeOrder(Order o){
        Customer c=o.customer; if(c.remove)return; c.state=3; c.tx=960; c.ty=340 + (c.id%3)*75; c.wait=1.2f;
    }

    private void serve(Customer c){
        if(c.remove)return; c.state=4; c.tx=1180;c.ty=650; c.wait=1.8f;
        float tip = c.patience>45 ? c.price*.12f : 0;
        float earned=c.price+tip; cash+=earned; dayTakings+=earned; served++; xp+=8+(int)c.price; reputation=Math.min(100,reputation+(c.patience>35?.18f:.05f));
        while(xp>=level*120){xp-=level*120;level++;cash+=50;}
        save();
    }

    private void endDay(){
        open=false; customers.clear(); orders.clear(); day++; shiftTime=8*60; dayTakings=0; open=true; reputation=Math.max(60,reputation-1); save();
    }

    private void drawFrame(){ Canvas c=null; try{c=getHolder().lockCanvas(); if(c==null)return; draw(c);} finally{if(c!=null)getHolder().unlockCanvasAndPost(c);} }
    private void draw(Canvas c){
        c.drawColor(Color.rgb(33,31,28)); float sx=W/1280f, sy=H/720f; c.save(); c.scale(sx,sy);
        drawCafe(c); drawEntities(c); drawHud(c); drawButtons(c); c.restore();
    }

    private void drawCafe(Canvas c){
        // floor
        p.setColor(Color.rgb(234,220,194)); c.drawRoundRect(35,95,1245,675,26,26,p);
        // checker floor
        p.setColor(Color.rgb(221,205,178)); for(int y=110;y<670;y+=70)for(int x=50;x<1240;x+=70)if(((x+y)/70)%2==0)c.drawRect(x,y,x+70,y+70,p);
        // walls / branding strip
        p.setColor(Color.rgb(36,31,27)); c.drawRoundRect(50,110,1230,180,20,20,p);
        p.setColor(Color.rgb(255,196,61)); c.drawRoundRect(65,125,250,165,18,18,p); label(c,"DEXTER'S",157,153,28,Color.rgb(30,27,24),Paint.Align.CENTER);
        label(c,"CAFÉ • BREAKFAST • LUNCH • TAKEAWAY",505,151,17,Color.WHITE,Paint.Align.LEFT);
        // counter
        p.setColor(Color.rgb(95,71,55)); c.drawRoundRect(420,195,650,305,18,18,p); p.setColor(Color.rgb(255,196,61));c.drawRect(430,205,640,225,p);
        label(c,"ORDER COUNTER  Lv"+counterLevel,535,250,18,Color.WHITE,Paint.Align.CENTER);
        // kitchen
        p.setColor(Color.rgb(80,84,86)); c.drawRoundRect(700,195,1015,305,18,18,p);
        label(c,"KITCHEN  Lv"+kitchenLevel,858,232,18,Color.WHITE,Paint.Align.CENTER);
        station(c,735,250,80,38,"GRILL"); station(c,825,250,80,38,"PREP"); station(c,915,250,80,38,"FRYER");
        // pass
        p.setColor(Color.rgb(47,113,79)); c.drawRoundRect(1025,215,1165,285,15,15,p); label(c,"PASS",1095,257,20,Color.WHITE,Paint.Align.CENTER);
        // tables
        for(int i=0;i<tables;i++){ float x=410+i*210; p.setColor(Color.rgb(129,86,57));c.drawOval(x,410,x+125,475,p); p.setColor(Color.rgb(79,55,42));c.drawRect(x+53,470,x+72,535,p); }
        // entrance and queue lane
        p.setColor(Color.rgb(80,80,80)); c.drawRoundRect(55,565,165,660,16,16,p); label(c,"DOOR",110,620,18,Color.WHITE,Paint.Align.CENTER);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(Color.rgb(130,118,100));c.drawRoundRect(210,370,355,645,18,18,p);p.setStyle(Paint.Style.FILL); label(c,"QUEUE",282,397,15,Color.DKGRAY,Paint.Align.CENTER);
        // bins/decor
        p.setColor(Color.rgb(71,126,73));c.drawCircle(1180,420,30,p);c.drawRect(1167,445,1193,500,p); label(c,"★",1180,437,25,Color.WHITE,Paint.Align.CENTER);
    }

    private void station(Canvas c,float x,float y,float w,float h,String s){p.setColor(Color.rgb(115,120,122));c.drawRoundRect(x,y,x+w,y+h,8,8,p);label(c,s,x+w/2,y+25,13,Color.WHITE,Paint.Align.CENTER);}

    private void drawEntities(Canvas c){
        for(Staff s:staff)s.draw(c);
        for(Customer x:customers)x.draw(c);
        // order tickets
        int n=0; for(Order o:orders){ float x=1030,y=315+n*54; p.setColor(Color.rgb(255,248,220));c.drawRoundRect(x,y,1215,y+45,8,8,p);label(c,o.item,1040,y+18,13,Color.DKGRAY,Paint.Align.LEFT); float pc=1f-o.remaining/o.total; p.setColor(Color.rgb(205,197,175));c.drawRect(1040,y+27,1200,y+35,p);p.setColor(Color.rgb(69,157,90));c.drawRect(1040,y+27,1040+160*pc,y+35,p);n++;if(n>=5)break;}
    }

    private void drawHud(Canvas c){
        p.setColor(Color.argb(235,20,19,18));c.drawRoundRect(25,18,1255,82,18,18,p);
        label(c,"DAY "+day,48,56,20,Color.WHITE,Paint.Align.LEFT);
        label(c,String.format(Locale.UK,"£%.2f",cash),175,56,23,Color.rgb(255,196,61),Paint.Align.LEFT);
        label(c,"REP "+(int)reputation+"%",320,56,18,Color.WHITE,Paint.Align.LEFT);
        label(c,"LV "+level+"  XP "+xp+"/"+(level*120),455,56,18,Color.WHITE,Paint.Align.LEFT);
        int hr=(int)(shiftTime/60)%24, min=(int)shiftTime%60; label(c,String.format(Locale.UK,"%02d:%02d",hr,min),720,56,20,Color.WHITE,Paint.Align.LEFT);
        label(c,"SERVED "+served,850,56,18,Color.WHITE,Paint.Align.LEFT);
        if(rush){p.setColor(Color.rgb(200,55,55));c.drawRoundRect(1010,31,1235,68,16,16,p);label(c,"🔥 LUNCH RUSH "+(int)rushClock+"s",1122,56,17,Color.WHITE,Paint.Align.CENTER);} else label(c,open?"OPEN":"CLOSED",1150,56,18,open?Color.rgb(87,210,112):Color.LTGRAY,Paint.Align.CENTER);
    }

    private void drawButtons(Canvas c){
        startButton.set(25,628,205,702);counterButton.set(225,628,455,702);kitchenButton.set(475,628,705,702);hireButton.set(725,628,955,702);
        button(c,startButton,"END DAY",Color.rgb(64,66,68));
        button(c,counterButton,"UPGRADE COUNTER £"+(90+counterLevel*70),Color.rgb(121,83,44));
        button(c,kitchenButton,"UPGRADE KITCHEN £"+(110+kitchenLevel*80),Color.rgb(76,104,126));
        button(c,hireButton,"HIRE RUNNER £180",Color.rgb(66,115,83));
        p.setColor(Color.rgb(255,196,61));c.drawRoundRect(975,628,1245,702,16,16,p);label(c,"TAP CUSTOMERS / STATIONS",1110,660,15,Color.rgb(30,27,24),Paint.Align.CENTER);label(c,"to help during the rush",1110,682,13,Color.rgb(30,27,24),Paint.Align.CENTER);
    }
    private void button(Canvas c,RectF r,String s,int color){p.setColor(color);c.drawRoundRect(r,14,14,p);label(c,s,r.centerX(),r.centerY()+7,15,Color.WHITE,Paint.Align.CENTER);}

    private void label(Canvas c,String s,float x,float y,float sz,int color,Paint.Align align){text.setTextSize(sz);text.setColor(color);text.setTextAlign(align);c.drawText(s,x,y,text);}

    @Override public boolean onTouchEvent(MotionEvent e){ if(e.getAction()!=MotionEvent.ACTION_DOWN)return true; float x=e.getX()*1280f/W,y=e.getY()*720f/H;
        if(startButton.contains(x,y)){endDay();return true;}
        if(counterButton.contains(x,y)){int cost=90+counterLevel*70;if(cash>=cost){cash-=cost;counterLevel++;save();}return true;}
        if(kitchenButton.contains(x,y)){int cost=110+kitchenLevel*80;if(cash>=cost){cash-=cost;kitchenLevel++;save();}return true;}
        if(hireButton.contains(x,y)){if(cash>=180 && staff.size()<5){cash-=180;staff.add(new Staff("Runner",1060,330,2));save();}return true;}
        for(Customer cust:customers){if(Math.hypot(x-cust.x,y-cust.y)<40){cust.patience=Math.min(100,cust.patience+12);return true;}}
        if(x>700&&x<1015&&y>195&&y<305){for(Order o:orders)o.remaining=Math.max(.1f,o.remaining-1.5f);return true;}
        if(x>420&&x<650&&y>195&&y<305){for(Customer cust:customers)if(cust.state==1)cust.wait-=1.2f;return true;}
        return true;
    }

    private void save(){prefs.edit().putFloat("cash",cash).putFloat("rep",reputation).putInt("day",day).putInt("served",served).putInt("level",level).putInt("xp",xp).putInt("counter",counterLevel).putInt("kitchen",kitchenLevel).putInt("tables",tables).apply();}
    private void load(){cash=prefs.getFloat("cash",60);reputation=prefs.getFloat("rep",82);day=prefs.getInt("day",1);served=prefs.getInt("served",0);level=prefs.getInt("level",1);xp=prefs.getInt("xp",0);counterLevel=prefs.getInt("counter",1);kitchenLevel=prefs.getInt("kitchen",1);tables=prefs.getInt("tables",3);}

    class Staff{
        String role;float x,y,tx,ty,speed;int kind;Staff(String r,float x,float y,int k){role=r;this.x=x;this.y=y;tx=x;ty=y;kind=k;speed=120;}
        void update(float dt){ if(kind==0){tx=535;ty=270;}else if(kind==1){tx=840;ty=320;}else{ Customer target=null;for(Customer c:customers)if(c.state==3){target=c;break;} if(target!=null){tx=target.x-35;ty=target.y;}else{tx=1060;ty=330;} } move(dt); }
        void move(float dt){float dx=tx-x,dy=ty-y,d=(float)Math.hypot(dx,dy);if(d>2){x+=dx/d*speed*dt;y+=dy/d*speed*dt;}}
        void draw(Canvas c){p.setColor(kind==0?Color.rgb(64,110,160):kind==1?Color.rgb(180,70,55):Color.rgb(63,135,86));c.drawCircle(x,y,23,p);p.setColor(Color.rgb(250,211,174));c.drawCircle(x,y-25,13,p);label(c,role,x,y+46,12,Color.DKGRAY,Paint.Align.CENTER);}
    }

    class Customer{
        float x,y,tx,ty,patience=100,price,wait=0;int state=0,queuePos,id;String item;boolean remove=false; int itemIndex;
        Customer(String it,float pr,float x,float y,int q,int idx){item=it;price=pr;this.x=x;this.y=y;queuePos=q;itemIndex=idx;id=rng.nextInt(9999);tx=282;ty=570-q*47;}
        void update(float dt){ patience-=dt*(rush?1.9f:1.05f); if(patience<=0){reputation=Math.max(40,reputation-2);state=4;tx=80;ty=650;}
            if(state==0 && near(tx,ty)){state=1;wait=1.8f/(1+.18f*(counterLevel-1));tx=365;ty=300;}
            else if(state==1){wait-=dt; if(wait<=0){state=2; Order o=new Order(this,item,3.7f/(1+.16f*(kitchenLevel-1)));orders.add(o);tx=350;ty=350+(id%4)*55;}}
            else if(state==3){wait-=dt;if(near(tx,ty)&&wait<=0){serve(this);}}
            else if(state==4 && near(tx,ty)){remove=true;}
            move(dt);
        }
        boolean near(float a,float b){return Math.hypot(x-a,y-b)<10;}
        void move(float dt){float dx=tx-x,dy=ty-y,d=(float)Math.hypot(dx,dy);if(d>3){float sp=95;x+=dx/d*sp*dt;y+=dy/d*sp*dt;}}
        void draw(Canvas c){int col=Color.rgb(80+(id*31)%130,80+(id*47)%130,80+(id*67)%130);p.setColor(col);c.drawCircle(x,y,22,p);p.setColor(Color.rgb(244,202,164));c.drawCircle(x,y-24,13,p);
            p.setColor(Color.rgb(65,65,65));c.drawRoundRect(x-34,y+28,x+34,y+43,6,6,p);p.setColor(patience>50?Color.rgb(70,180,95):patience>25?Color.rgb(230,160,55):Color.rgb(210,65,55));c.drawRoundRect(x-32,y+30,x-32+64*(patience/100f),y+41,5,5,p);
            label(c,item,x,y-45,11,Color.DKGRAY,Paint.Align.CENTER);
        }
    }

    class Order{Customer customer;String item;float remaining,total;boolean done=false;Order(Customer c,String i,float t){customer=c;item=i;remaining=t;total=t;}void update(float dt){remaining-=dt*(rush?.93f:1f);if(remaining<=0)done=true;}}
}
