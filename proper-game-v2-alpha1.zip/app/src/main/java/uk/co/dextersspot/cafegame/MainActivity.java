package uk.co.dextersspot.cafegame;

import android.app.Activity;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

public class MainActivity extends Activity {
    private CafeGameView gameView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        hideSystemUi();
        gameView = new CafeGameView(this);
        setContentView(gameView);
    }

    private void hideSystemUi() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController c = getWindow().getInsetsController();
            if (c != null) c.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
        } else {
            getWindow().getDecorView().setSystemUiVisibility(5894 | 4096);
        }
    }

    @Override protected void onResume() { super.onResume(); hideSystemUi(); if (gameView != null) gameView.resumeGame(); }
    @Override protected void onPause() { if (gameView != null) gameView.pauseGame(); super.onPause(); }
}
