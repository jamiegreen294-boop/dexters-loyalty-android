plugins { id("com.android.application") }
android {
    namespace = "uk.co.dextersspot.cafegame"
    compileSdk = 35
    defaultConfig {
        applicationId = "uk.co.dextersspot.cafegame"
        minSdk = 26
        targetSdk = 35
        versionCode = 20
        versionName = "2.0.0-alpha1"
    }
}
