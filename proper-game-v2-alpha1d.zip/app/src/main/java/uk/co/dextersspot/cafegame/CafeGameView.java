package uk.co.dextersspot.cafegame;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.*;
import android.view.*;
import java.util.*;

public class CafeGameView extends SurfaceView implements SurfaceHolder.Callback, Runnable {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private Thread loop;
    private volatile boolean running;
    private long lastNs;
    private float W = 1280, H = 720;

    private final ArrayList<Customer> customers = new ArrayList<>();
    private final ArrayList<Staff> staff = new ArrayList<>();
    private final ArrayList<Order> orders = new ArrayList<>();
    private final ArrayList<PopFx> pops = new ArrayList<>();

    private final String[] menu = {"Coffee","Breakfast Roll","Full Scottish","Street Sub","Nero Smash","Loaded Fries","Rice Bowl","Waffle"};
    private final float[] price = {3.2f,4.5f,9.95f,7.5f,10.5f,6.5f,9.5f,7.25f};
    // 0 coffee, 1 grill, 2 prep, 3 fryer, 4 dessert
    private final int[] stationFor = {0,1,1,2,1,3,2,4};

    private float cash = 60f, reputation = 82f, dayTakings = 0f, shiftTime = 8*60f;
    private float spawnClock = 0f, rushClock = 0f, stationFlash = 0f;
    private int served = 0, day = 1, level = 1, xp = 0, counterLevel = 1, kitchenLevel = 1, tables = 4;
    private boolean open = true, rush = false, paused = false;
    private final SharedPreferences prefs;

    private final RectF endDayButton = new RectF();
    private final RectF counterButton = new RectF();
    private final RectF kitchenButton = new RectF();
    private final RectF hireButton = new RectF();
    private final RectF grillTap = new RectF(704,208,785,288);
    private final RectF prepTap = new RectF(792,208,873,288);
    private final RectF fryerTap = new RectF(880,208,961,288);
    private final RectF coffeeTap = new RectF(522,218,590,295);

    public CafeGameView(Context c) {
        super(c);
        getHolder().addCallback(this);
        setFocusable(true);
        prefs = c.getSharedPreferences("dexters_native_game_v2", Context.MODE_PRIVATE);
        load();
        text.setTypeface(Typeface.create("sans", Typeface.BOLD));
        staff.add(new Staff("Cashier", 510, 306, 0));
        staff.add(new Staff("Chef", 820, 304, 1));
        if (prefs.getBoolean("runner", false)) staff.add(new Staff("Runner", 1025, 405, 2));
    }

    @Override public void surfaceCreated(SurfaceHolder h) {
        running = true; lastNs = System.nanoTime(); loop = new Thread(this); loop.start();
    }
    @Override public void surfaceDestroyed(SurfaceHolder h) {
        running = false; save(); try { if (loop != null) loop.join(800); } catch (Exception ignored) {}
    }
    @Override public void surfaceChanged(SurfaceHolder h, int f, int w, int ht) { W = w; H = ht; }
    public void resumeGame() { paused = false; lastNs = System.nanoTime(); }
    public void pauseGame() { paused = true; save(); }

    @Override public void run() {
        while (running) {
            long now = System.nanoTime();
            float dt = Math.min(.035f, (now-lastNs)/1_000_000_000f); lastNs = now;
            if (!paused) update(dt);
            drawFrame();
            try { Thread.sleep(12); } catch (Exception ignored) {}
        }
    }

    private void update(float dt) {
        if (open) {
            shiftTime += dt * 2.0f;
            spawnClock -= dt;
            if (spawnClock <= 0 && customers.size() < (rush ? 12 : 9)) {
                spawnCustomer();
                spawnClock = rush ? 1.15f : Math.max(2.0f, 3.2f - level*.05f);
            }
        }
        if (stationFlash > 0) stationFlash -= dt;
        if (rush) {
            rushClock -= dt;
            if (rushClock <= 0) { rush = false; reputation = Math.min(100, reputation + 1.2f); pop("Rush survived! +REP", 1035, 105, 0xff65d27d); }
        }
        if (!rush && served > 0 && served % 12 == 0 && rng.nextFloat() < dt*.12f) { rush = true; rushClock = 30; pop("LUNCH RUSH!", 1030, 105, 0xffffc43d); }

        for (Staff s : staff) s.update(dt);
        for (int i=customers.size()-1; i>=0; i--) {
            Customer c = customers.get(i); c.update(dt); if (c.remove) customers.remove(i);
        }
        for (int i=orders.size()-1; i>=0; i--) {
            Order o = orders.get(i); o.update(dt); if (o.done) { completeOrder(o); orders.remove(i); }
        }
        for (int i=pops.size()-1; i>=0; i--) { pops.get(i).update(dt); if (pops.get(i).life<=0) pops.remove(i); }
        if (shiftTime >= 18*60 && open) open = false;
    }

    private void spawnCustomer() {
        int q = queueCount(); int idx = rng.nextInt(menu.length);
        Customer c = new Customer(menu[idx], price[idx], 58, 570, q, idx);
        customers.add(c);
    }
    private int queueCount() { int n=0; for (Customer c:customers) if(c.state<=1) n++; return n; }

    private void completeOrder(Order o) {
        Customer c = o.customer; if (c.remove) return;
        c.state = 3; c.hasFood = true;
        if (c.sitIn) { int t = Math.abs(c.id)%Math.max(1,tables); c.tx = 610 + (t%2)*230; c.ty = 450 + (t/2)*95; }
        else { c.tx = 1060; c.ty = 355; }
        c.wait = 1.2f;
        pop("READY", 1000, 255, 0xff6edc87);
    }

    private void serve(Customer c) {
        if (c.remove || c.paid) return;
        c.paid = true;
        float tip = c.patience > 55 ? c.price*.15f : c.patience > 30 ? c.price*.06f : 0;
        float earned = c.price + tip;
        cash += earned; dayTakings += earned; served++; xp += 8 + (int)c.price;
        reputation = Math.min(100, reputation + (c.patience>50?.25f:.08f));
        pop(String.format(Locale.UK,"+£%.2f",earned), c.x, c.y-55, 0xffffc43d);
        if (tip>0) pop("TIP!", c.x+40, c.y-80, 0xff79df93);
        while (xp >= level*120) { xp -= level*120; level++; cash += 50; pop("LEVEL UP! +£50", 650, 115, 0xffffc43d); }
        c.state = 5; c.tx = 60; c.ty = 570; c.wait = c.sitIn ? 3.8f : 1.3f;
        save();
    }

    private void endDay() {
        open=false; customers.clear(); orders.clear(); day++; shiftTime=8*60; dayTakings=0; open=true;
        reputation=Math.max(60,reputation-1); spawnClock=.5f; save();
        pop("DAY "+day,640,150,0xffffc43d);
    }

    private void drawFrame() {
        Canvas c=null;
        try { c=getHolder().lockCanvas(); if(c==null)return; renderGame(c); }
        finally { if(c!=null)getHolder().unlockCanvasAndPost(c); }
    }

    private void renderGame(Canvas c) {
        c.drawColor(Color.rgb(24,25,28));
        float sx=W/1280f, sy=H/720f; c.save(); c.scale(sx,sy);
        drawWorld(c); drawEntities(c); drawHud(c); drawBottomBar(c); drawFx(c); c.restore();
    }

    private void drawWorld(Canvas c) {
        // room shell
        fill(c, 22,90,1258,624, 28, 0xffefe6d3);
        // back wall warm plaster
        fill(c, 36,104,1244,218,20,0xff2e3132);
        // timber fascia
        fill(c,58,122,392,190,16,0xffb46b30);
        label(c,"DEXTER'S",225,166,34,Color.WHITE,Paint.Align.CENTER);
        label(c,"CAFÉ  •  BREAKFAST  •  LUNCH  •  TAKEAWAY",420,161,17,0xfff4efe5,Paint.Align.LEFT);
        // hanging lights
        for(int i=0;i<5;i++){float x=455+i*140; p.setColor(0xff111111);c.drawRect(x-2,106,x+2,128,p);c.drawCircle(x,135,11,p); p.setColor(0x44ffc43d);c.drawCircle(x,143,25,p);}
        // tiled kitchen backsplash
        for(int y=198;y<318;y+=30) for(int x=660;x<1010;x+=50){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(1);p.setColor(0xffc9c9c5);c.drawRect(x,y,x+50,y+30,p);} p.setStyle(Paint.Style.FILL);

        // wood floor planks with perspective-ish alternating tone
        int row=0; for(int y=318;y<624;y+=46){ int col=0; for(int x=36;x<1244;x+=105){ p.setColor(((row+col)%2==0)?0xffc89562:0xffbc8755);c.drawRect(x,y,x+103,y+44,p); col++; } row++; }
        // rug / queue route
        fill(c,110,402,365,600,18,0x332d2b29);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);p.setColor(0xff84796c);c.drawRoundRect(170,402,345,595,24,24,p);p.setStyle(Paint.Style.FILL);
        label(c,"QUEUE",255,426,14,0xff5e554d,Paint.Align.CENTER);

        drawCounter(c);
        drawKitchen(c);
        drawTables(c);
        drawCollection(c);
        drawDecor(c);
    }

    private void drawCounter(Canvas c){
        // service counter with display case
        fill(c,385,208,620,326,14,0xff5a3829);
        fill(c,385,208,620,225,8,0xffd19a59);
        // glass cake case
        fill(c,400,235,478,294,8,0x8878b9c4);
        p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(0xffdce9e8);c.drawRoundRect(400,235,478,294,8,8,p);p.setStyle(Paint.Style.FILL);
        // pastries
        for(int i=0;i<3;i++){p.setColor(0xffe1a448);c.drawOval(410+i*20,260,426+i*20,270,p);}
        // till
        fill(c,488,238,532,269,5,0xff27292b); fill(c,493,242,527,258,3,0xff7aa7a9);
        // coffee machine
        fill(c,538,220,596,288,8,0xff25282a); p.setColor(0xffaab1b2);c.drawCircle(553,240,7,p);c.drawCircle(578,240,7,p);
        fill(c,548,270,586,285,4,0xffc5ccd0);
        label(c,"ORDER",500,316,14,0xfff5ede3,Paint.Align.CENTER);
        label(c,"COFFEE",568,316,13,0xfff5ede3,Paint.Align.CENTER);
        // tap glow
        if(stationFlash>0){p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(5);p.setColor(0xffffc43d);c.drawRoundRect(coffeeTap,12,12,p);p.setStyle(Paint.Style.FILL);}
    }

    private void drawKitchen(Canvas c){
        // prep line
        fill(c,650,194,992,322,18,0xff555a5d);
        fill(c,666,208,976,222,4,0xffc7cccd);
        drawAppliance(c,704,222,785,294,"GRILL",1);
        drawAppliance(c,792,222,873,294,"PREP",2);
        drawAppliance(c,880,222,961,294,"FRYER",3);
        label(c,"KITCHEN  Lv"+kitchenLevel,820,315,15,Color.WHITE,Paint.Align.CENTER);
        // shelf + pans
        fill(c,668,172,965,187,3,0xff343738);
        for(int i=0;i<4;i++){p.setColor(0xffbfc5c6);c.drawCircle(700+i*70,180,7,p);}
    }

    private void drawAppliance(Canvas c,float l,float t,float r,float b,String name,int type){
        fill(c,l,t,r,b,10,0xff737a7d); fill(c,l+8,t+9,r-8,t+27,5,0xff2a2d2f);
        if(type==1){for(int i=0;i<4;i++){p.setColor(0xffc65a36);c.drawRect(l+12+i*14,t+37,l+22+i*14,b-10,p);}}
        else if(type==2){p.setColor(0xff73ad65);c.drawCircle((l+r)/2-12,t+48,10,p);p.setColor(0xffe94f45);c.drawCircle((l+r)/2+10,t+48,8,p);}
        else {p.setColor(0xffffc43d);c.drawRect(l+18,t+38,r-18,b-10,p);for(int i=0;i<5;i++){p.setColor(0xffe5a12f);c.drawRect(l+22+i*9,t+34,l+27+i*9,b-12,p);}}
        label(c,name,(l+r)/2,b-7,11,Color.WHITE,Paint.Align.CENTER);
    }

    private void drawTables(Canvas c){
        float[][] t={{560,405},{780,405},{560,518},{780,518}};
        for(int i=0;i<tables && i<t.length;i++){
            float x=t[i][0], y=t[i][1];
            // chairs
            fill(c,x-72,y-16,x-38,y+34,8,0xff343130); fill(c,x+38,y-16,x+72,y+34,8,0xff343130);
            // tabletop shadow + top
            p.setColor(0x33000000);c.drawOval(x-52,y-12,x+56,y+44,p);p.setColor(0xff8b5a3c);c.drawOval(x-55,y-18,x+55,y+34,p);
            // condiment caddy
            fill(c,x-8,y-10,x+10,y+8,3,0xff2e2b28);p.setColor(0xffd94236);c.drawCircle(x-3,y-12,4,p);p.setColor(0xffe7c43d);c.drawCircle(x+5,y-12,4,p);
        }
    }

    private void drawCollection(Canvas c){
        fill(c,1007,215,1208,326,16,0xff315f49);
        fill(c,1024,231,1192,270,8,0xffd8bd8c);
        // takeaway bags
        for(int i=0;i<3;i++){fill(c,1040+i*45,238,1070+i*45,264,3,0xffcaa46b);label(c,"D",1055+i*45,256,12,0xff3a3129,Paint.Align.CENTER);}
        label(c,"COLLECTION",1107,306,16,Color.WHITE,Paint.Align.CENTER);
    }

    private void drawDecor(Canvas c){
        // front door
        fill(c,40,454,126,608,10,0xff2d363a); fill(c,52,469,114,548,4,0xff76a9b8); label(c,"OPEN",83,580,13,0xff7fe096,Paint.Align.CENTER);
        // plant wall + planters
        fill(c,1050,115,1230,190,10,0xff263f2d);
        for(int i=0;i<12;i++){p.setColor(i%2==0?0xff4d8f4c:0xff6cad58);c.drawCircle(1062+(i*31)%155,128+(i%3)*22,12,p);}
        // neon sign
        label(c,"Dexter's",1140,170,24,0xffff6a5e,Paint.Align.CENTER);
        // chalkboard
        fill(c,160,122,350,192,8,0xff202425); label(c,"GOOD FOOD • GOOD PEOPLE",255,151,13,0xfff4efe5,Paint.Align.CENTER); label(c,"FRESH • FAST • LOCAL",255,175,12,0xfff4efe5,Paint.Align.CENTER);
    }

    private void drawEntities(Canvas c){
        for(Staff s:staff) s.draw(c);
        for(Customer x:customers) x.draw(c);
        // kitchen order rail
        int n=0;
        for(Order o:orders){
            float x=1018+(n%2)*100, y=335+(n/2)*58;
            fill(c,x,y,x+92,y+48,8,0xfffff6dc);
            drawFoodIcon(c,o.customer.itemIndex,x+22,y+23,0.65f);
            float pc=1f-o.remaining/o.total;
            p.setColor(0xffd8cfb5);c.drawRect(x+42,y+14,x+84,y+21,p);
            p.setColor(0xff54b86c);c.drawRect(x+42,y+14,x+42+42*pc,y+21,p);
            label(c,shortName(o.item),x+47,y+38,9,0xff4a4339,Paint.Align.CENTER);
            n++; if(n>=6) break;
        }
    }

    private void drawHud(Canvas c){
        fill(c,18,14,1262,80,18,0xee17191b);
        // level badge
        p.setColor(0xffffc43d);c.drawCircle(55,47,23,p);label(c,""+level,55,55,21,0xff1f2021,Paint.Align.CENTER);
        // xp bar
        label(c,"LEVEL",91,34,10,0xffb9bec0,Paint.Align.LEFT);
        fill(c,90,42,244,62,10,0xff3a4043);float xpPc=Math.min(1f,xp/(float)(level*120));p.setColor(0xff3aa8dd);c.drawRoundRect(92,44,92+150*xpPc,60,8,8,p);label(c,xp+" / "+(level*120)+" XP",167,57,11,Color.WHITE,Paint.Align.CENTER);
        // cash
        p.setColor(0xffffc43d);c.drawCircle(286,47,19,p);label(c,"£",286,54,18,0xff4e3a1d,Paint.Align.CENTER);label(c,String.format(Locale.UK,"£%.2f",cash),316,55,21,0xffffc43d,Paint.Align.LEFT);
        // rep
        label(c,"★",477,55,22,0xffffc43d,Paint.Align.CENTER);label(c,(int)reputation+"% REP",500,55,17,Color.WHITE,Paint.Align.LEFT);
        // clock/day
        int hr=(int)(shiftTime/60)%24,min=(int)shiftTime%60; label(c,"DAY "+day,706,35,11,0xffb9bec0,Paint.Align.CENTER);label(c,String.format(Locale.UK,"%02d:%02d",hr,min),706,59,22,Color.WHITE,Paint.Align.CENTER);
        // served / takings
        label(c,"SERVED",838,35,11,0xffb9bec0,Paint.Align.CENTER);label(c,""+served,838,59,21,Color.WHITE,Paint.Align.CENTER);
        label(c,"TODAY",936,35,11,0xffb9bec0,Paint.Align.CENTER);label(c,String.format(Locale.UK,"£%.0f",dayTakings),936,59,21,0xffffc43d,Paint.Align.CENTER);
        if(rush){fill(c,1006,25,1243,67,16,0xffbb3e35);label(c,"🔥 LUNCH RUSH  "+(int)rushClock+"s",1124,53,17,Color.WHITE,Paint.Align.CENTER);}
        else {fill(c,1072,26,1238,66,15,open?0xff2e8458:0xff55595c);label(c,open?"OPEN":"CLOSED",1155,53,17,Color.WHITE,Paint.Align.CENTER);}
    }

    private void drawBottomBar(Canvas c){
        fill(c,18,632,1262,710,18,0xee1c2225);
        endDayButton.set(35,646,190,696); counterButton.set(207,646,422,696); kitchenButton.set(438,646,653,696); hireButton.set(669,646,884,696);
        actionButton(c,endDayButton,"END DAY","Shift summary",0xff454a4d);
        actionButton(c,counterButton,"COUNTER Lv"+counterLevel,"Upgrade £"+(90+counterLevel*70),0xff9a6534);
        actionButton(c,kitchenButton,"KITCHEN Lv"+kitchenLevel,"Upgrade £"+(110+kitchenLevel*80),0xff3e7189);
        actionButton(c,hireButton,hasRunner()?"RUNNER HIRED":"HIRE RUNNER",hasRunner()?"Serving tables":"£180",0xff3e8059);
        fill(c,904,646,1244,696,13,0xffffc43d);label(c,"TAP PEOPLE OR EQUIPMENT TO HELP",1074,666,14,0xff241f1a,Paint.Align.CENTER);label(c,"during busy service",1074,684,11,0xff4b3b23,Paint.Align.CENTER);
    }

    private void actionButton(Canvas c,RectF r,String a,String b,int color){p.setColor(color);c.drawRoundRect(r,13,13,p);label(c,a,r.centerX(),r.top+21,13,Color.WHITE,Paint.Align.CENTER);label(c,b,r.centerX(),r.top+40,10,0xffe1e4e5,Paint.Align.CENTER);}

    private void drawFx(Canvas c){ for(PopFx fx:pops)fx.draw(c); }

    private void drawPerson(Canvas c,float x,float y,int body,int hair,boolean apron,boolean staffPerson,float bob){
        y += bob;
        // shadow
        p.setColor(0x33000000);c.drawOval(x-22,y+31,x+22,y+43,p);
        // legs
        p.setStrokeWidth(7);p.setStrokeCap(Paint.Cap.ROUND);p.setColor(0xff303438);c.drawLine(x-9,y+16,x-11,y+34,p);c.drawLine(x+9,y+16,x+11,y+34,p);
        // torso
        p.setColor(body);c.drawRoundRect(x-18,y-15,x+18,y+18,9,9,p);
        if(apron){p.setColor(0xff161718);c.drawRoundRect(x-13,y-5,x+13,y+21,6,6,p);label(c,"D",x,y+10,10,Color.WHITE,Paint.Align.CENTER);}
        // arms
        p.setColor(0xffefbd94);c.drawCircle(x-21,y,6,p);c.drawCircle(x+21,y,6,p);
        // head
        p.setColor(0xffefbd94);c.drawCircle(x,y-27,14,p);
        // hair
        p.setColor(hair);c.drawArc(x-14,y-41,x+14,y-18,180,180,true,p);c.drawRect(x-14,y-31,x-11,y-21,p);
        // face
        p.setColor(0xff3d2a22);c.drawCircle(x-5,y-27,1.5f,p);c.drawCircle(x+5,y-27,1.5f,p);
        if(staffPerson){p.setColor(0xff111111);c.drawArc(x-7,y-23,x+7,y-16,10,160,false,p);}
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    private void drawFoodIcon(Canvas c,int idx,float x,float y,float s){
        c.save(); c.translate(x,y); c.scale(s,s);
        switch(idx){
            case 0: // coffee
                p.setColor(0xfff7f4ed);c.drawRoundRect(-16,-12,10,12,5,5,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(4);c.drawArc(5,-8,19,9,-80,170,false,p);p.setStyle(Paint.Style.FILL);p.setColor(0xff6f3e22);c.drawRect(-13,-9,7,-4,p);break;
            case 1: case 3: // roll/sub
                p.setColor(0xffdf9b48);c.drawOval(-24,-9,24,10,p);p.setColor(0xff67a447);c.drawRect(-18,-2,18,4,p);p.setColor(0xffd64d3c);c.drawRect(-15,2,15,6,p);break;
            case 2: // breakfast plate
                p.setColor(0xfff7f4ed);c.drawCircle(0,0,23,p);p.setColor(0xfff6c944);c.drawCircle(-7,-4,8,p);p.setColor(0xff7c492d);c.drawRect(3,-10,16,-4,p);c.drawRect(3,2,17,8,p);break;
            case 4: // burger
                p.setColor(0xffe7a646);c.drawOval(-22,-15,22,-2,p);p.setColor(0xff5b3122);c.drawRect(-19,-1,19,6,p);p.setColor(0xff6aa54b);c.drawRect(-18,6,18,10,p);p.setColor(0xffe7a646);c.drawOval(-21,9,21,17,p);break;
            case 5: // fries
                p.setColor(0xffd83e31);c.drawRect(-16,-2,16,18,p);p.setColor(0xffffc43d);for(int i=0;i<5;i++)c.drawRect(-14+i*7,-17+(i%2)*3,-9+i*7,3,p);break;
            case 6: // bowl
                p.setColor(0xfff4f0e8);c.drawArc(-22,-12,22,18,0,180,true,p);p.setColor(0xff68a45a);c.drawCircle(-6,-4,6,p);p.setColor(0xffdf8e3f);c.drawCircle(7,-2,6,p);break;
            default: // waffle
                p.setColor(0xffd79a46);c.drawRect(-18,-18,18,18,p);p.setStyle(Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(0xff9e692f);for(int i=-12;i<=12;i+=8){c.drawLine(i,-18,i,18,p);c.drawLine(-18,i,18,i,p);}p.setStyle(Paint.Style.FILL);break;
        }
        c.restore();
    }

    private String shortName(String s){ if(s.length()<=12)return s; if(s.contains("Breakfast"))return "Breakfast"; if(s.contains("Scottish"))return "Scottish"; if(s.contains("Loaded"))return "Fries"; return s.substring(0,11); }
    private boolean hasRunner(){ for(Staff s:staff)if(s.kind==2)return true; return false; }
    private void fill(Canvas c,float l,float t,float r,float b,float rad,int color){p.setColor(color);c.drawRoundRect(l,t,r,b,rad,rad,p);}
    private void label(Canvas c,String s,float x,float y,float sz,int color,Paint.Align align){text.setTextSize(sz);text.setColor(color);text.setTextAlign(align);c.drawText(s,x,y,text);}
    private void pop(String s,float x,float y,int color){pops.add(new PopFx(s,x,y,color));}

    @Override public boolean onTouchEvent(MotionEvent e){
        if(e.getAction()!=MotionEvent.ACTION_DOWN)return true;
        float x=e.getX()*1280f/W, y=e.getY()*720f/H;
        if(endDayButton.contains(x,y)){endDay();return true;}
        if(counterButton.contains(x,y)){int cost=90+counterLevel*70;if(cash>=cost){cash-=cost;counterLevel++;pop("COUNTER UPGRADED",500,185,0xffffc43d);save();}return true;}
        if(kitchenButton.contains(x,y)){int cost=110+kitchenLevel*80;if(cash>=cost){cash-=cost;kitchenLevel++;pop("KITCHEN UPGRADED",820,170,0xffffc43d);save();}return true;}
        if(hireButton.contains(x,y)){if(cash>=180&&!hasRunner()){cash-=180;staff.add(new Staff("Runner",1025,405,2));prefs.edit().putBoolean("runner",true).apply();pop("RUNNER HIRED",1010,400,0xff79df93);save();}return true;}
        // customer tap restores a little patience
        for(Customer cust:customers){if(Math.hypot(x-cust.x,y-cust.y)<38){cust.patience=Math.min(100,cust.patience+10);pop("+PATIENCE",cust.x,cust.y-55,0xff79df93);return true;}}
        // station taps accelerate relevant orders
        if(coffeeTap.contains(x,y)){boostStation(0);stationFlash=.25f;return true;}
        if(grillTap.contains(x,y)){boostStation(1);return true;}
        if(prepTap.contains(x,y)){boostStation(2);return true;}
        if(fryerTap.contains(x,y)){boostStation(3);return true;}
        return true;
    }

    private void boostStation(int station){boolean hit=false;for(Order o:orders){if(o.station==station){o.remaining=Math.max(.08f,o.remaining-1.15f);hit=true;}}if(hit)pop("BOOST!",station==0?558:station==1?744:station==2?832:920,205,0xffffc43d);}

    private void save(){prefs.edit().putFloat("cash",cash).putFloat("rep",reputation).putInt("day",day).putInt("served",served).putInt("level",level).putInt("xp",xp).putInt("counter",counterLevel).putInt("kitchen",kitchenLevel).putInt("tables",tables).putBoolean("runner",hasRunner()).apply();}
    private void load(){cash=prefs.getFloat("cash",60);reputation=prefs.getFloat("rep",82);day=prefs.getInt("day",1);served=prefs.getInt("served",0);level=prefs.getInt("level",1);xp=prefs.getInt("xp",0);counterLevel=prefs.getInt("counter",1);kitchenLevel=prefs.getInt("kitchen",1);tables=prefs.getInt("tables",4);}

    class Staff {
        String role; float x,y,tx,ty,speed,bob=0; int kind;
        Staff(String r,float x,float y,int k){role=r;this.x=x;this.y=y;tx=x;ty=y;kind=k;speed=125;}
        void update(float dt){bob=(float)Math.sin(System.nanoTime()/180_000_000.0+kind)*1.3f;
            if(kind==0){tx=510;ty=306;}
            else if(kind==1){Order work=null;for(Order o:orders){work=o;break;} if(work!=null){tx=work.station==1?744:work.station==2?832:work.station==3?920:835;ty=310;}else{tx=820;ty=304;}}
            else {Customer target=null;for(Customer c:customers)if(c.state==3&&c.hasFood){target=c;break;}if(target!=null){tx=target.x-34;ty=target.y;}else{tx=1010;ty=385;}}
            move(dt);
        }
        void move(float dt){float dx=tx-x,dy=ty-y,d=(float)Math.hypot(dx,dy);if(d>2){x+=dx/d*speed*dt;y+=dy/d*speed*dt;}}
        void draw(Canvas c){int body=kind==0?0xff2f6f99:kind==1?0xffa84035:0xff397950;drawPerson(c,x,y,body,0xff2f241f,true,true,bob);label(c,role,x,y+57,11,0xff35302c,Paint.Align.CENTER);}
    }

    class Customer {
        float x,y,tx,ty,patience=100,price,wait=0,bob=0; int state=0,queuePos,id,itemIndex; String item; boolean remove=false,sitIn,hasFood=false,paid=false;
        int body,hair;
        Customer(String it,float pr,float x,float y,int q,int idx){item=it;price=pr;this.x=x;this.y=y;queuePos=q;itemIndex=idx;id=rng.nextInt(99999);sitIn=rng.nextFloat()<.62f;body=Color.rgb(70+rng.nextInt(130),70+rng.nextInt(120),80+rng.nextInt(120));hair=rng.nextBoolean()?0xff38261d:0xff6b3f23;tx=255;ty=550-q*42;}
        void update(float dt){bob=(float)Math.sin(System.nanoTime()/210_000_000.0+(id%20))*1.1f; patience-=dt*(rush?1.65f:.88f);if(patience<=0&&state<4){reputation=Math.max(40,reputation-2);state=5;tx=60;ty=570;pop("WALKOUT -REP",x,y-65,0xffdf5a52);}
            if(state==0&&near(tx,ty)){state=1;wait=1.7f/(1+.18f*(counterLevel-1));tx=390;ty=330;}
            else if(state==1){wait-=dt;if(wait<=0){state=2;orders.add(new Order(this,item,3.8f/(1+.17f*(kitchenLevel-1)),stationFor[itemIndex]));tx=385;ty=390+(id%4)*42;}}
            else if(state==3){wait-=dt;if(near(tx,ty)&&wait<=0){serve(this);}}
            else if(state==5){wait-=dt;if(near(tx,ty)&&wait<=0)remove=true;}
            move(dt);
        }
        boolean near(float a,float b){return Math.hypot(x-a,y-b)<10;}
        void move(float dt){float dx=tx-x,dy=ty-y,d=(float)Math.hypot(dx,dy);if(d>3){float sp=rush?110:92;x+=dx/d*sp*dt;y+=dy/d*sp*dt;}}
        void draw(Canvas c){
            drawPerson(c,x,y,body,hair,false,false,bob);
            // speech bubble / food icon
            if(state<=2){fill(c,x-31,y-78,x+31,y-42,12,0xfffbf7ee);p.setColor(0xfffbf7ee);Path tri=new Path();tri.moveTo(x-5,y-43);tri.lineTo(x+5,y-43);tri.lineTo(x,y-35);tri.close();c.drawPath(tri,p);drawFoodIcon(c,itemIndex,x,y-60,.55f);}
            if(hasFood){drawFoodIcon(c,itemIndex,x+25,y+7,.45f);}
            // patience bar
            fill(c,x-28,y+43,x+28,y+50,4,0xff4c4c49);int pc=patience>55?0xff54b86c:patience>28?0xffe9a43b:0xffd64f47;p.setColor(pc);c.drawRoundRect(x-27,y+44,x-27+54*Math.max(0,patience)/100f,y+49,3,3,p);
        }
    }

    class Order {
        Customer customer; String item; float remaining,total; boolean done=false; int station;
        Order(Customer c,String i,float t,int s){customer=c;item=i;remaining=t;total=t;station=s;}
        void update(float dt){remaining-=dt*(rush?.95f:1f);if(remaining<=0)done=true;}
    }

    class PopFx {
        String s; float x,y,life=1.35f; int color;
        PopFx(String s,float x,float y,int color){this.s=s;this.x=x;this.y=y;this.color=color;}
        void update(float dt){life-=dt;y-=dt*22;}
        void draw(Canvas c){int a=(int)(255*Math.max(0,life/1.35f));label(c,s,x,y,14,(a<<24)|(color&0x00ffffff),Paint.Align.CENTER);}
    }
}
